//
//  ReportExportService.swift
//  NexGenSpec
//
//  Runs report generation on background. Use for large inspections to avoid UI freeze.
//

import Foundation
import UIKit

/// Result of background report export.
public enum ReportExportResult {
    case success(htmlURL: URL?, pdfURL: URL?)
    case failure(Error)
}

/// Runs HTML and PDF generation off the main thread. Report progress 0...1.
/// Images are written to a temp folder (imageFolderURL) and referenced by path in HTML to avoid loading all photos in memory (batch/stream-friendly for large reports).
@MainActor
public final class ReportExportService: ObservableObject {

    @Published public private(set) var isExporting = false
    @Published public private(set) var progress: Double = 0
    @Published public private(set) var result: ReportExportResult?
    @Published public private(set) var errorMessage: String?

    public init() {}

    /// Export report for version. Updates progress and result on main.
    public func export(version: InspectionVersion) async {
        guard !isExporting else { return }
        isExporting = true
        progress = 0
        result = nil
        errorMessage = nil
        let versionCopy = version
        // Heavy work (HTML + write) off main thread; then PDF on main (WKWebView needs main).
        let htmlResult: (htmlURL: URL?, reportDir: URL, tempHTML: URL)? = await Task.detached(priority: .userInitiated) {
            await Task.yield()
            var htmlURL: URL?
            do {
                let reportDir = FileManager.default.temporaryDirectory.appendingPathComponent("report-\(versionCopy.id.uuidString)", isDirectory: true)
                let imagesDir = reportDir.appendingPathComponent("images", isDirectory: true)
                let videosDir = reportDir.appendingPathComponent("videos", isDirectory: true)
                try FileManager.default.createDirectory(at: imagesDir, withIntermediateDirectories: true)
                try FileManager.default.createDirectory(at: videosDir, withIntermediateDirectories: true)
                let html = HTMLReportRenderer.renderHTML(for: versionCopy, imageFolderURL: imagesDir, videosFolderURL: videosDir)
                let tempHTML = reportDir.appendingPathComponent("index.html")
                try html.write(to: tempHTML, atomically: true, encoding: .utf8)
                htmlURL = tempHTML
                return (htmlURL, reportDir, tempHTML)
            } catch {
                return nil
            }
        }.value
        progress = 0.7
        var finalResult: ReportExportResult
        if let htmlResult {
            // PDFReportRenderer hops to main thread internally when needed (WKWebView requires main).
            let pdfURL = await PDFReportRenderer.generatePDF(fromHTMLFile: htmlResult.tempHTML, baseURL: htmlResult.reportDir)
            let resolvedPDF = pdfURL ?? PDFReportRenderer.generatePDF(for: versionCopy)
            progress = 1
            if let resolvedPDF {
                finalResult = .success(htmlURL: htmlResult.htmlURL, pdfURL: resolvedPDF)
            } else {
                finalResult = .failure(NSError(domain: "ReportExport", code: -1, userInfo: [NSLocalizedDescriptionKey: "PDF could not be generated. The report may be too large."]))
            }
        } else {
            progress = 1
            finalResult = .failure(NSError(domain: "ReportExport", code: -2, userInfo: [NSLocalizedDescriptionKey: "Report export failed."]))
        }
        self.result = finalResult
        self.isExporting = false
        self.progress = 1
        if case .failure(let error) = finalResult {
            self.errorMessage = error.localizedDescription
        }
    }

    public func reset() {
        result = nil
        progress = 0
        errorMessage = nil
    }
}
